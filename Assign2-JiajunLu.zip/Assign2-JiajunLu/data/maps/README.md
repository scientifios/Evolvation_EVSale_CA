Put California ZIP/ZCTA GeoJSON here and name it:

ca_zcta.geojson

The main project can run the county overview without this file, but ZIP drill-down needs it.
