const CONFIG = {
  countySalesUrl: "data/clean/county_sales_nested.json",
  zipSalesUrl: "data/clean/zip_sales_nested.json",
  timelineUrl: "data/clean/timeline.json",
  usCountiesTopoUrl: "https://cdn.jsdelivr.net/npm/us-atlas@3/counties-10m.json",
  zctaGeoJsonUrl: "data/maps/ca_zcta.geojson",
  width: 1120,
  height: 690,
  fuels: ["Electric", "Hydrogen", "PHEV"],
  colors: {
    Electric: "#f2c94c",
    Hydrogen: "#2f80ed",
    PHEV: "#27ae60"
  }
};

const svg = d3.select("#map");
const root = svg.append("g").attr("class", "root");
const areaLayer = root.append("g").attr("class", "areas");
const glyphLayer = root.append("g").attr("class", "glyphs");
const tooltip = d3.select("#tooltip");
const statusMessage = d3.select("#statusMessage");
const timeSlider = d3.select("#timeSlider");
const periodLabel = d3.select("#periodLabel");
const backButton = d3.select("#backButton");

let countySales = {};
let zipSales = {};
let timeline = [];
let countyFeatures = [];
let zctaFeatures = [];
let selectedCounty = null;
let selectedCountyFeature = null;
let periodIndex = 0;
let currentView = "state";
let projection = d3.geoMercator();
let path = d3.geoPath(projection);
let currentTransform = d3.zoomIdentity;

const zoom = d3.zoom()
  .scaleExtent([0.75, 12])
  .on("zoom", (event) => {
    currentTransform = event.transform;
    root.attr("transform", currentTransform);
  });

svg.call(zoom);

d3.select("#zoomIn").on("click", () => svg.transition().duration(250).call(zoom.scaleBy, 1.35));
d3.select("#zoomOut").on("click", () => svg.transition().duration(250).call(zoom.scaleBy, 0.75));
d3.select("#resetZoom").on("click", resetZoom);
backButton.on("click", () => renderStateView(true));

function setStatus(message, visible = true) {
  statusMessage.classed("hidden", !visible).text(message || "");
}

function normalizeName(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/\b\w/g, c => c.toUpperCase());
}

function getCountyName(feature) {
  return normalizeName(feature.properties?.name || feature.properties?.NAME || feature.properties?.county || feature.properties?.COUNTY);
}

function getZip(feature) {
  const p = feature.properties || {};
  return String(p.ZCTA5CE20 || p.ZCTA5CE10 || p.GEOID20 || p.GEOID10 || p.GEOID || p.ZIP || p.zip || "").padStart(5, "0");
}

function salesForArea(dataset, period, key) {
  return dataset?.[period]?.[key] || { Electric: 0, Hydrogen: 0, PHEV: 0, total: 0 };
}

function maxSales(dataset, keys = null) {
  let maxValue = 1;
  for (const period of Object.keys(dataset || {})) {
    for (const [key, record] of Object.entries(dataset[period])) {
      if (keys && !keys.has(String(key))) continue;
      for (const fuel of CONFIG.fuels) maxValue = Math.max(maxValue, Number(record[fuel] || 0));
    }
  }
  return maxValue;
}

function radiusScaleFor(dataset, keys = null) {
  return d3.scaleSqrt().domain([0, maxSales(dataset, keys)]).range([0, 28]);
}

function radius(value, scale) {
  const v = Number(value || 0);
  return v > 0 ? Math.max(2.2, scale(v)) : 0;
}

function circleLayout(record, scale) {
  const rE = radius(record.Electric, scale);
  const rH = radius(record.Hydrogen, scale);
  const rP = radius(record.PHEV, scale);

  const e = { type: "Electric", value: record.Electric || 0, r: rE, x: 0, y: 0, color: CONFIG.colors.Electric };
  const h = { type: "Hydrogen", value: record.Hydrogen || 0, r: rH, x: rE + rH, y: 0, color: CONFIG.colors.Hydrogen };

  let px = 0;
  let py = 0;
  const d = rE + rH;
  if (rP > 0 && rE > 0 && rH > 0 && d > 0) {
    px = ((rE + rP) ** 2 - (rH + rP) ** 2 + d ** 2) / (2 * d);
    py = -Math.sqrt(Math.max(0, (rE + rP) ** 2 - px ** 2));
  } else if (rP > 0) {
    px = d / 2;
    py = -rP - Math.max(rE, rH, 2);
  }
  const p = { type: "PHEV", value: record.PHEV || 0, r: rP, x: px, y: py, color: CONFIG.colors.PHEV };

  const visible = [e, h, p].filter(d => d.r > 0);
  const minX = d3.min(visible, d => d.x - d.r) || 0;
  const maxX = d3.max(visible, d => d.x + d.r) || 0;
  const minY = d3.min(visible, d => d.y - d.r) || 0;
  const maxY = d3.max(visible, d => d.y + d.r) || 0;
  const cx = (minX + maxX) / 2;
  const cy = (minY + maxY) / 2;

  return [e, h, p].map(d => ({ ...d, x: d.x - cx, y: d.y - cy }));
}

function formatNumber(v) {
  return d3.format(",")(Number(v || 0));
}

function showTooltip(event, html) {
  const [x, y] = d3.pointer(event, svg.node());
  tooltip.classed("hidden", false)
    .style("left", `${x + 18}px`)
    .style("top", `${y + 18}px`)
    .html(html);
}

function hideTooltip() {
  tooltip.classed("hidden", true);
}

function areaTooltip(name, record) {
  return `<strong>${name}</strong>
    Electric: ${formatNumber(record.Electric)}<br>
    Hydrogen: ${formatNumber(record.Hydrogen)}<br>
    PHEV: ${formatNumber(record.PHEV)}<br>
    <b>Total: ${formatNumber(record.total)}</b>`;
}

function glyphTooltip(name, period, circle) {
  return `<strong>${name}</strong>${period}<br>${circle.type}: <b>${formatNumber(circle.value)}</b>`;
}

async function init() {
  svg.attr("viewBox", `0 0 ${CONFIG.width} ${CONFIG.height}`);
  setStatus("Loading data…");

  const [countyData, zipData, timelineData, usTopo] = await Promise.all([
    d3.json(CONFIG.countySalesUrl),
    d3.json(CONFIG.zipSalesUrl),
    d3.json(CONFIG.timelineUrl),
    d3.json(CONFIG.usCountiesTopoUrl)
  ]);

  countySales = countyData || {};
  zipSales = zipData || {};
  timeline = timelineData || Object.keys(countySales).sort();
  countyFeatures = topojson.feature(usTopo, usTopo.objects.counties).features
    .filter(d => String(d.id).padStart(5, "0").startsWith("06"));

  try {
    const zcta = await d3.json(CONFIG.zctaGeoJsonUrl);
    zctaFeatures = zcta.features || [];
  } catch (err) {
    zctaFeatures = [];
    console.warn("ZIP/ZCTA GeoJSON not found yet:", err);
  }

  timeSlider.attr("max", Math.max(0, timeline.length - 1)).attr("value", periodIndex);
  timeSlider.on("input", (event) => {
    periodIndex = Number(event.target.value);
    updatePeriod();
  });
  timeSlider.on("wheel", (event) => {
    event.preventDefault();
    periodIndex = Math.max(0, Math.min(timeline.length - 1, periodIndex + (event.deltaY > 0 ? 1 : -1)));
    timeSlider.property("value", periodIndex);
    updatePeriod();
  }, { passive: false });

  renderStateView(false);
}

function resetZoom() {
  svg.transition().duration(350).call(zoom.transform, d3.zoomIdentity);
}

function fitProjectionTo(features) {
  projection = d3.geoMercator().fitSize([CONFIG.width, CONFIG.height], { type: "FeatureCollection", features });
  path = d3.geoPath(projection);
}

function renderStateView(animate) {
  currentView = "state";
  selectedCounty = null;
  selectedCountyFeature = null;
  backButton.classed("hidden", true);
  setStatus("", false);
  fitProjectionTo(countyFeatures);
  areaLayer.selectAll("*").remove();
  glyphLayer.selectAll("*").remove();
  resetZoom();

  areaLayer.selectAll("path")
    .data(countyFeatures, d => d.id)
    .join("path")
    .attr("class", "county")
    .attr("d", path)
    .on("mousemove", (event, d) => {
      const name = getCountyName(d);
      const record = salesForArea(countySales, timeline[periodIndex], name);
      showTooltip(event, areaTooltip(`${name} County`, record));
    })
    .on("mouseout", hideTooltip)
    .on("click", (event, d) => renderCountyView(d));

  updatePeriod(animate);
}

function renderCountyView(countyFeature) {
  currentView = "county";
  selectedCountyFeature = countyFeature;
  selectedCounty = getCountyName(countyFeature);
  backButton.classed("hidden", false);
  areaLayer.selectAll("*").remove();
  glyphLayer.selectAll("*").remove();
  resetZoom();

  if (!zctaFeatures.length) {
    setStatus(`ZIP/ZCTA boundary file is missing. Put California ZCTA GeoJSON at data/maps/ca_zcta.geojson, then click ${selectedCounty} County again.`);
    fitProjectionTo([countyFeature]);
    areaLayer.append("path").datum(countyFeature).attr("class", "county").attr("d", path);
    updatePeriod(true);
    return;
  }

  const countyZips = zctaFeatures.filter(z => {
    const zip = getZip(z);
    const hasSales = timeline.some(period => zipSales?.[period]?.[zip]);
    if (!hasSales) return false;
    return d3.geoContains(countyFeature, d3.geoCentroid(z));
  });

  if (!countyZips.length) {
    setStatus(`No ZIP polygons matched ${selectedCounty} County. Check that ca_zcta.geojson uses California ZCTA/ZIP boundaries.`);
    fitProjectionTo([countyFeature]);
    areaLayer.append("path").datum(countyFeature).attr("class", "county").attr("d", path);
    updatePeriod(true);
    return;
  }

  setStatus("", false);
  fitProjectionTo(countyZips);

  areaLayer.selectAll("path")
    .data(countyZips, d => getZip(d))
    .join("path")
    .attr("class", "zip-area")
    .attr("d", path)
    .on("mousemove", (event, d) => {
      const zip = getZip(d);
      const record = salesForArea(zipSales, timeline[periodIndex], zip);
      showTooltip(event, areaTooltip(`ZIP ${zip}`, record));
    })
    .on("mouseout", hideTooltip);

  updatePeriod(true);
}

function updatePeriod(animate = true) {
  const period = timeline[periodIndex] || "";
  periodLabel.text(period);

  if (currentView === "state") {
    renderGlyphs({
      features: countyFeatures,
      keyFn: getCountyName,
      nameFn: d => `${getCountyName(d)} County`,
      dataset: countySales,
      scale: radiusScaleFor(countySales),
      animate
    });
  } else {
    if (!selectedCountyFeature || !zctaFeatures.length) return;
    const zipFeatures = areaLayer.selectAll("path").data();
    const keys = new Set(zipFeatures.map(getZip));
    renderGlyphs({
      features: zipFeatures,
      keyFn: getZip,
      nameFn: d => `ZIP ${getZip(d)}`,
      dataset: zipSales,
      scale: radiusScaleFor(zipSales, keys),
      animate
    });
  }
}

function renderGlyphs({ features, keyFn, nameFn, dataset, scale, animate }) {
  const period = timeline[periodIndex];

  const groups = glyphLayer.selectAll("g.glyph")
    .data(features, d => keyFn(d));

  groups.exit().transition().duration(250).style("opacity", 0).remove();

  const enter = groups.enter()
    .append("g")
    .attr("class", "glyph")
    .style("opacity", 0)
    .attr("transform", d => `translate(${path.centroid(d)})`);

  enter.append("title");
  enter.transition().duration(350).style("opacity", 1);

  const merged = enter.merge(groups)
    .attr("transform", d => `translate(${path.centroid(d)})`);

  merged.each(function(feature) {
    const g = d3.select(this);
    const key = keyFn(feature);
    const record = salesForArea(dataset, period, key);
    const circles = circleLayout(record, scale);
    g.select("title").text(`${nameFn(feature)} ${period}: ${formatNumber(record.total)} total`);

    const circleSel = g.selectAll("circle")
      .data(circles, d => d.type)
      .join(
        enter => enter.append("circle")
          .attr("cx", 0).attr("cy", 0).attr("r", 0)
          .attr("fill", d => d.color)
          .attr("fill-opacity", 0.88)
          .attr("stroke", "white")
          .attr("stroke-width", 1.2)
          .on("mousemove", (event, d) => showTooltip(event, glyphTooltip(nameFn(feature), period, d)))
          .on("mouseout", hideTooltip),
        update => update,
        exit => exit.transition().duration(250).attr("r", 0).remove()
      );

    const t = animate ? circleSel.transition().duration(650).ease(d3.easeCubicOut) : circleSel;
    t.attr("cx", d => d.x).attr("cy", d => d.y).attr("r", d => d.r);
  });
}

init().catch(err => {
  console.error(err);
  setStatus(`Could not load the project data. Check that data/clean/*.json exists and run through a local server. Error: ${err.message}`);
});
